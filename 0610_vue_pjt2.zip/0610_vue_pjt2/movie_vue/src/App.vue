<template>
  <div id="app">
    <div id="nav">
      <router-link :to="{name:'ArticleList'}">목록으로</router-link> |
      <span v-if='!isLogin'>
         <router-link :to="{name:'Signup'}">Signup</router-link> |
        <router-link :to="{name:'Login'}">Login</router-link> |
      </span>
      <span v-else>
         <router-link to='/accounts/logout' @click.native='logout'>Logout</router-link>
         <!-- <router-link to=''></router-link> -->
      </span>
      
    </div>
    
    <router-view @login='login' @signup='signup'/>
  </div>
</template>
<script>
import axios from 'axios'
const BASE_URL = 'http://127.0.0.1:8000'
  export default {
    name : 'App',
    data () {
      return {
        isLogin : false,
        // articles : [{'ff':1}],
      }
    },
    mounted() {
        this.isLogin = this.$cookies.isKey('auth-token')
    },
    methods: {
        setCookie(key){
          this.$cookies.set('auth-token', key)
          this.isLogin = true
        },
        
        signup(signupData){
          console.log(signupData)
          axios.post(BASE_URL + '/rest-auth/signup/', signupData)
          // .then(res => {
          //   this.setCookie(res.data.key)
          //   this.isLogin = true
          //   this.$router.push({ name: "ArticleList" })
          // })
          .then(() => {
            const newAccount = {username : signupData.username, password : signupData.password1}
            axios.post(BASE_URL+'/rest-auth/login/',newAccount)
            .then(res=>{
              this.setCookie(res.data.key)
              this.$router.push({name : 'ArticleList'})
            })
            .catch(err=>console.log(err.resonse))
          
          })
          .catch(err => {
            console.log(err.response)
          })

        },

        login(loginData) {
          axios.post(BASE_URL+'/rest-auth/login/',loginData)
          .then(res => {
            console.log(res)
            this.setCookie(res.data.key)
            this.$router.push({name:'ArticleList'})
          })
          .catch(err=>{
            console.log(err.response)
          })

        },
        logout() {
          const requestHeaders = {
            headers: {
              Authorization: 'Token ' + this.$cookies.get('auth-token')
            }
          }
          axios.post(BASE_URL+'/rest-auth/logout/', null, requestHeaders)
          .then(() => {
            this.$cookies.remove('auth-token')
            this.isLogin = false
            this.$router.push({ name: 'ArticleList'})
          })
          .catch(err => {
            console.log(err.response)
          })
        },
      // getList(event) {
      //   console.log('목록으로 이동',event)
      //   axios.get(BASE_URL+'/articles/')
      //   .then(res=>{
      //     console.log(res)
      //     this.articles = res.data
      //   })
      //   .catch(err=>console.log(err.response))
      // }
        
    },
  }
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
