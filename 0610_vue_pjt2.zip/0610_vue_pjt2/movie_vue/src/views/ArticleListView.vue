<template>
  <div>
    <div v-if="isLogin">
     <button class="btn btn-success"><router-link :to="{name:'ArticleCreate'}" class="text-white">글쓰기</router-link> </button>
     </div>
    <h1 class="my-3">게시판</h1>
    <hr/>
    <span style='margin-right:10em'>Title</span>
            <span>작성자</span> 
    <hr/>
    <div class='container'>
       <div v-for="article in articles" :key='article.id'>
            <span style='margin-right:10em'>{{article.title}}</span>
            <span>{{article.user.username}}</span> 
            
            <hr/>
      </div>
   </div>

  </div>
</template>

<script>
import axios from 'axios'
const BASE_URL = 'http://127.0.0.1:8000'

export default {
name : 'ArticleListView',

data () {
  return {
    articles : {},
    isLogin : false,
  }
},
mounted() {
  this.isLogin = this.$cookies.isKey('auth-token')
  console.log('mounted')
  axios.get(BASE_URL+'/articles/')
  .then(res=>{
    console.log(res)
    this.articles = res.data
  })
  .catch(err=>console.log(err.response))

},

}
</script>

<style>

</style>