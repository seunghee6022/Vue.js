<template>
  <div>
    <h1>로그인</h1>
    아이디 : <input type='text' v-model='loginData.username'>
    <br>
    비밀번호 : <input type='password' v-model='loginData.password'>
    <br>
    <button @click='login'>확인</button>
  </div>
</template>

<script>
export default {
name : 'LoginView',
data () {
  return {
    loginData : {
      username : '',
      password : '',
    }
  }
},
methods : {
  login(){
    console.log(this.loginData)
    this.$emit("login", this.loginData)

  }
}
}
</script>

<style>

</style>