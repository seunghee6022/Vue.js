<template>
  <div>
    <h1>회원가입</h1>
    아이디: <input type="text" v-model="signupData.username">
    <br>
    비밀번호: <input type="password" v-model="signupData.password1">
    <br>
    비밀번호 확인: <input type="password" v-model="signupData.password2">
    <br>
    <button @click="signup">확인</button>
  </div>
</template>

<script>
export default {
  name : 'SignupView',
  data() {
    return {
      signupData: {
        username: null,
        password1: null,
        password2: null,
      },
    }
  },

  methods: {
    signup() {
      this.$emit('signup', this.signupData)
    }
  }
}
</script>

<style>

</style>