<template>
  <div>
      <div v-if="isLogin" class="mb-3">
      <button class='btn btn-success'><router-link :to="{name:'ArticleCreate'}" class="text-white">글쓰기</router-link> </button>
      </div>
   <h1>커뮤니티</h1>
  <div class="m-3">
    <form>
    <div class="form-group">
        <label for="exampleInputEmail1">title:</label>
        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" v-model="articleData.title">
        
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Content:</label>
        <textarea class="form-control" id="exampleInputPassword1" v-model="articleData.content"></textarea>
        <small id="emailHelp" class="form-text text-muted">영화와 관련된 자유로운 의견을 남겨주세요.</small>
    </div>
    <button type="submit" class="btn btn-primary" @click="createArticle">작성하기</button>
    </form>
  </div>

</div>

</template>

<script>
import axios from 'axios'

const BASE_URL = 'http://127.0.0.1:8000'

export default {
    name:'ArticleCreateView',
    data() {
        return{
            articleData: {
                title: null,
                content: null,
            },
            isLogin : false,
        }
    },
    mounted() {
        this.isLogin = this.$cookies.isKey('auth-token')
    },
    methods: {
        createArticle() {
            const requestHeaders = {
                headers: {
                    Authorization: 'Token ' + this.$cookies.get('auth-token')
                }
            }
            axios.post(BASE_URL + '/articles/create/', this.articleData, requestHeaders)
            .then(res => {
                console.log(res)
                this.$router.push({name:'ArticleList'})
            })
            .catch(err => {
                console.log(err.response)
            })
        }
    }
}
</script>

<style>

</style>